"""
GoLismero plugins API.
"""

__all__ = ["VERSION"]

from .. import __version__ as VERSION
