#!/bin/sh
py.test --cov ../../golismero/ --cov-report html 
