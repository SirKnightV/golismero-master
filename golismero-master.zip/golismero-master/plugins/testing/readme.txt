Testing plugins go here. These plugins run the actual security tests against the targets.

They are divided into two subcategories: discovery (the information gathering phase) and attack (the vulnerability assessment phase).